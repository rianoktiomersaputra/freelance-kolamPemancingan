<?php

/**
 * @version 1.27.0
 */

require __DIR__.'/vendor/autoload.php';
